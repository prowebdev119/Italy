<?

include("config.php"); //db connection and directory variables
include("lang.php");


 $maxnumber = 12;
 $count= 0;
 $index = 0;
 $cardcount = 0;
 $cardindex = 0;
 $cards[0];
 $thecards[0][0];
 while($count <= $maxnumber)
{
     $number = rand(0,78);
     for($index; $index <= $maxnumber; $index++)
     {
        if($cards[$index] == $number)
        {
          $number = rand(0,78);
          $index = -1;
        }

     }
      $cards[$count] = $number;
      $randnum = rand(0,100);
      if($count != 0)
      {
        if(($randnum % 2) != 0)
        {
          $cards[$count] =  $cards[$count]."r";
        }
      }

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
       $sendprint = $printcards."&maxnumber=".$maxnumber;
?>


<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<TITLE>Metodo Astrologico - Lettura Tarocchi Gratis - Reponso.</TITLE>
<META NAME="Title" Content="Metodo Astrologico - Lettura Tarocchi Gratis - Reponso">
<META NAME="Description" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Keywords" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Robots" Content="Index,Follow">
<META NAME="Language" Content="Italian it">
<META NAME="Autor" Content="Giaas">
<META NAME="Copyright" Content="� 2010 Giaas">
<link rel="stylesheet" type="text/css" href="tarot.css">
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106475490-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-106475490-1');
</script>
</head>

<body class="body" topmargin="0" marginheight="0">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="genericstyle">
            <tr>
                <td colspan="4" align="center">
                    <p><SPAN class="header1"><?php include("alto.htm"); ?>
<br><? echo"$astropagetitle";?></span><br>
</b></p>
                </td>
            </tr>
            <tr>
                <td colspan="4" align="left">

                    <p><br>
                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x15, creato 24/02/10 */
google_ad_slot = "0763580921";
google_ad_width = 728;
google_ad_height = 15;
//-->

                        

                        
                    

                        

                        
                    
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                                
                                                                    
                    
                    </script>
<br><br><?echo"$titleblurb";?></p>
                    <p align="center">
<br>&nbsp;</p></td>
            </tr>
            <tr>
                <td colspan="4" valign="middle" align="center">

                    <p><a href="index.htm"><font color="#990000"><b><?echo"$readlink";?></b></font></a><b><font color="#990000">
        &nbsp;&nbsp;&nbsp;</font><a href="disclaimer.htm" target="_blank"><font color="#990000"><?echo"$disclaimlink";?></font></a><font color="#990000"><!--&nbsp;&nbsp;&nbsp;<a href="interp.htm" target="_blank"><?echo"$interplink";?></a>-->&nbsp;&nbsp;&nbsp;</font></b><a href="astroprint.php?pcards=<?echo $sendprint;?>" target="_blank"><font color="#990000"><b><?echo"$printlink";?><br></b></font></A></p>
                    <p>

                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "8653742807";
google_ad_width = 728;
google_ad_height = 90;
//-->

            

            
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                        
                    </script>
<br>&nbsp;</p>
                </td>
            </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[11][2]; $large=$thecards[11][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[12][2]; $large=$thecards[12][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"vspace="2"></a></td>
      <td align="center"><a href="<? $thumb=$thecards[10][2]; $large=$thecards[10][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a></td>
      <td align="center"><a href="<? $thumb=$thecards[9][2]; $large=$thecards[9][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a></td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="80%" class="genericstyle">
            <tr>
                <td colspan="2" width="<?echo"$tablewidth";?>"> 
                    <p align="center"><br>
                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "5217054529";
google_ad_width = 728;
google_ad_height = 90;
//-->

                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                    </script>
<br>&nbsp; </p>
                </td>
            </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="header1"><?echo"$selfheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $selfcard = $thecards[0][0]; echo"$selfcard";?>
        
        <p><? $selfmeaning = $thecards[0][1]; echo"$selfmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$currentheader";?></span></td>
    </tr>
    <tr>
     <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $moodcard = $thecards[1][0]; echo"$moodcard";?>
        
        <p><? $moodmeaning = $thecards[1][1]; echo"$moodmeaning";?></td>
    </tr>
<td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$financeheader";?></span></td>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $financecard = $thecards[2][0]; echo"$financecard";?>
        
        <p><? $financemeaning = $thecards[2][1]; echo"$financemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$travelheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $financecard = $thecards[3][0]; echo"$financecard";?>
        
        <p><? $financemeaning = $thecards[3][1]; echo"$financemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$homeheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $homecard = $thecards[4][0]; echo"$homecard";?>
        
        <p><? $homemeaning = $thecards[4][1]; echo"$homemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="83%" valign="top"><SPAN class="header1"><?echo"$pleasureheader";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pleasurecard = $thecards[5][0]; echo"$pleasurecard";?>
        
        <p><? $pleasuremeaning = $thecards[5][1]; echo"$pleasuremeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="83%" valign="top"><SPAN class="header1"><?echo"$healthheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $healthcard = $thecards[6][0]; echo"$healthcard";?>
        
        <p><? $healthmeaning = $thecards[6][1]; echo"$healthmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="header1"><?echo"$partnerheader";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $libracard = $thecards[7][0]; echo"$libracard";?>
        
        <p><? $librameaning = $thecards[7][1]; echo"$librameaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="header1"><?echo"$deathheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $deathcard = $thecards[8][0]; echo"$deathcard";?>
        
        <p><? $deathmeaning = $thecards[8][1]; echo"$deathmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="header1"><?echo"$spiritheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[9][2]; $large=$thecards[9][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $spiritcard = $thecards[9][0]; echo"$spiritcard";?>
        
        <p><? $spiritmeaning = $thecards[9][1]; echo"$spiritmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="header1"><?echo"$careerheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[10][2]; $large=$thecards[10][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $jobcard = $thecards[10][0]; echo"$jobcard";?>
        
        <p><? $jobmeaning = $thecards[10][1]; echo"$jobmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="header1"><?echo"$friendheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[11][2]; $large=$thecards[11][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $friendcard = $thecards[11][0]; echo"$friendcard";?>
        
        <p><? $friendmeaning = $thecards[11][1]; echo"$friendmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="header1"><?echo"$burdenheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[12][2]; $large=$thecards[12][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $fearcard = $thecards[12][0]; echo"$fearcard";?>
        
        <p><? $fearmeaning = $thecards[12][1]; echo"$fearmeaning";?></td>
    </tr>
            <tr>
                <td colspan="4" valign="middle" align="center">
                    <p>

                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "4490136035";
google_ad_width = 728;
google_ad_height = 90;
//-->

                        

                        
                        

                        

                        
                        
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                                
                                                                        
                        
                    </script>
</p>
                    <p><a href="index.htm"><font color="#990000"><b>Nuova Lettura</b></font></a><b><font color="#990000">&nbsp;&nbsp;&nbsp; </font><a href="disclaimer.htm" target="_blank"><font color="#990000">Disclaimer</font></a><font color="#990000">&nbsp;&nbsp;&nbsp;</font></b><a href="planetprint.php?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank"><font color="#990000"><b><?echo"$printlink";?></b></font></A></p>
                    <P><SPAN class="copyright"><?echo"$copyright";?></SPAN></P>
                </td>
            </tr>
  </table>        <p><?php include("basso.htm"); ?></p>
        <p>
</p>

  </center>
</div>

</body>

</html>