<?
include("config.php"); //db connection and directory variables
include("lang.php");
 $pcards = $_GET['pcards'];
 $maxnumber = $_GET['maxnumber'];
 $count= 0;
 $index = 0;
 $cards = explode (":", $pcards);

 while($count <= $maxnumber)
{

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
?>


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" type="text/css" href="tarot.css">
<title><?echo"$cctitle";?></title>
</head>

<body class="printbody">

<p>&nbsp;</p>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="4" align="center"></td>
    </tr>
    <tr>
      <td colspan="4" align="center" ><SPAN class="printheader">
        <? echo"$ccpagetitle";?></span><br>
        </b></td>
    </tr>
        <tr>
      <td colspan="3" align="center"><a href="<?$thumb=$thecards[2][2]; $large=$thecards[2][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td rowspan="4"><a href="<?$thumb=$thecards[9][2]; $large=$thecards[9][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <BR><a href="<?$thumb=$thecards[8][2]; $large=$thecards[8][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <BR><a href="<?$thumb=$thecards[7][2]; $large=$thecards[7][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <BR><a href="<?$thumb=$thecards[6][2]; $large=$thecards[6][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
      </td>
    </tr>
    <tr>
      <td align="right"><a href="<?$thumb=$thecards[3][2]; $large=$thecards[3][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
      <td align="center"><a href="<?$thumb=$thecards[1][2]; $large=$thecards[1][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><BR>
      <a href="<?$thumb=$thecards[0][2]; $large=$thecards[0][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
      <td align="center"><a href="<?$thumb=$thecards[5][2]; $large=$thecards[5][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
    </tr>
    <tr>
      <td align="center"></td>
      <td align="center"><a href="<?$thumb=$thecards[4][2]; $large=$thecards[4][3]; echo "$imagedirectory$largeimage$large"?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
      <td align="center"></td>
    </tr>
    <tr>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="5" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td width="445" colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" width="455"><SPAN class="printheader"><?echo"$sigheader";?></SPAN><?echo"$sigtext";?></td>
    </tr>
    <tr>
      <td width="17%"><a href="<?$thumb=$thecards[0][2]; $large=$thecards[0][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</td>
      <td width="83%" valign="top"><? $sigcard = $thecards[0][0]; echo"$sigcard";?>
        
        <p><? $sigmeaning = $thecards[0][1]; echo"$sigmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$crossheader";?></SPAN><?echo"$crosstext";?></td>
    </tr>
    <tr>
       <td width="17%"><a href="<?$thumb=$thecards[1][2]; $large=$thecards[1][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><? $crosscard = $thecards[1][0]; echo"$crosscard";?>
        </font>
        <p><? $crossmeaning = $thecards[1][1]; echo"$crossmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td colspan="2" width="83%"><SPAN class="printheader"><?echo"$foundationheader";?></span><?echo"$foundationtext";?></td>
    </tr>
    <tr>
       <td width="17%"><a href="<?$thumb=$thecards[4][2]; $large=$thecards[4][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><? $foundcard = $thecards[4][0]; echo"$foundcard";?>
        </font>
        <p><? $foundmeaning = $thecards[4][1]; echo"$foundmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$recentheader";?></span><?echo"$recenttext";?></font></td>
    </tr>
    <tr>
       <td width="17%"><a href="<?$thumb=$thecards[3][2]; $large=$thecards[3][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><? $pastcard = $thecards[3][0]; echo"$pastcard";?>
        </font>
        <p><? $pastmeaning = $thecards[3][1]; echo"$pastmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$crownheader";?></SPAN><?echo"$crowntext";?></td>
    </tr>
    <tr>
       <td width="17%" valign="top"><a href="<?$thumb=$thecards[2][2]; $large=$thecards[2][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><? $crowncard = $thecards[2][0]; echo"$crowncard";?>
        </font>
        <p><? $crownmeaning = $thecards[2][1]; echo"$crownmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$futureheader";?></span><?echo"$futuretext";?></font></td>
    </tr>
    <tr>
       <td width="17%" valign="top"><a href="<?$thumb=$thecards[5][2]; $large=$thecards[5][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="83%" valign="top"><? $futurecard = $thecards[5][0]; echo"$futurecard";?>
        </font>
        <p><? $futuremeaning = $thecards[5][1]; echo"$futuremeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$emotionsheader";?></SPAN><?echo"$emotionstext";?></font>
      </td>
    </tr>
    <tr>
       <td width="17%"><a href="<?$thumb=$thecards[6][2]; $large=$thecards[6][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="83%" valign="top"><? $emotecard = $thecards[6][0]; echo"$emotecard";?>
        </font>
        <p><? $emotemeaning = $thecards[6][1]; echo"$emotemeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$externheader";?></SPAN><?echo"$externtext";?></font></td>
    </tr>
    <tr>
       <td width="17%"><a href="<?$thumb=$thecards[7][2]; $large=$thecards[7][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="83%" valign="top"><? $externcard = $thecards[7][0]; echo"$externcard";?>
        </font>
        <p><? $externmeaning = $thecards[7][1]; echo"$externmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$hopesheader";?></SPAN><?echo"$hopestext";?></font>
      </td>
    </tr>
    <tr>
       <td width="17%"><a href="<?$thumb=$thecards[8][2]; $large=$thecards[8][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="83%" valign="top"><? $hopecard = $thecards[8][0]; echo"$hopecard";?>
        </font>
        <p><? $hopemeaning = $thecards[8][1]; echo"$hopemeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$outcomeheader";?></SPAN><?echo"$outcometext";?></font></td>
    </tr>
    <tr>
       <td width="17%"><a href="<?$thumb=$thecards[9][2]; $large=$thecards[9][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo $imagedirectory."/".$thumb;?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="83%" valign="top"><? $outcard = $thecards[9][0]; echo"$outcard";?>
        </font>
        <p><? $outmeaning = $thecards[9][1]; echo"$outmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      </td>
        <br>
      </td>
    </tr>
    <tr>
        <td colspan="4" valign="middle" align="center"><P class="printcopyright"><?echo"$copyright";?></P></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>