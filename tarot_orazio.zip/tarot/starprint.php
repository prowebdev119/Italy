<?

include("config.php"); //db connection and directory variables
include("lang.php");
$pcards = $_GET['pcards'];
$maxnumber = $_GET['maxnumber'];

 $count= 0;
 $index = 0;
 $cards = explode (":", $pcards);
 while($count <= $maxnumber)
{
      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       
?>


<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><?echo"$title";?></title>
<link rel="stylesheet" type="text/css" href="tarot.css">
</head>

<body class="printbody">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" align="center">
        <SPAN class="printheader"><? echo"$stpagetitle";?></span><br>&nbsp;
        </b></td>
    </tr>
     <tr>
      <td align="center" colspan="2"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        </td>
    </tr>

    <tr>
      <td><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        </td>
      <td align="right"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        </td>
    </tr>
    <tr>
      <td align="center" colspan="2"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        </td>
    </tr>
    <tr>
      <td><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        </td>
      <td align="right"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        </td>
    </tr>
    <tr>
      <td colspan="2">&nbsp;</td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="5" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$stpresent";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $presentcard = $thecards[0][0]; echo"$presentcard";?>
        
        <p><? $presentmeaning = $thecards[0][1]; echo"$presentmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$stcauses";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $selfcard = $thecards[1][0]; echo"$selfcard";?>
        
        <p><? $selfmeaning = $thecards[1][1]; echo"$selfmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$stchanges";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $changecard = $thecards[2][0]; echo"$changecard";?>
        
        <p><? $changemeaning = $thecards[2][1]; echo"$changemeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$ststrengths";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $strengthcard = $thecards[3][0]; echo"$strengthcard";?>
        
        <p><? $strengthmeaning = $thecards[3][1]; echo"$strengthmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$stchallenges";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $othercard = $thecards[4][0]; echo"$othercard";?>
        
        <p><? $othermeaning = $thecards[4][1]; echo"$othermeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$stoutcome";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $finalcard = $thecards[5][0]; echo"$finalcard";?>
        
        <p><? $finalmeaning = $thecards[5][1]; echo"$finalmeaning";?></td>
    </tr>
    <tr>
        <td valign="middle" align="center" colspan="2"><P><SPAN class="printcopyright"><?echo"$copyright";?></span></P></td>
    </tr>
   </table>
  </center>
</div>

</body>

</html>