<?
//shared language variables
$titleblurb = "Fai scorrere la pagina verso il basso per leggere l'intepretazione dei Tarocchi. Clicca Sulla Carta per i dettagli."; //blurb under page header
$readlink = "Cambia Metodo di Consulto";
$disclaimlink = "Disclaimer";
$interplink = "Intepretazione Base";
$printlink = "Versione Stampabile";
$copyright = "Copyright: Giaas 2010";

//the variables below define the celtic cross page's wording. use these to edit headers and header text
$cctitle = "Metodo della Croce Celtica: Lettura Tarocchi Gratis On Line - Responso"; // page title
$ccpagetitle = "Metodo della Croce Celtica: Il Responso dei Tarocchi"; // page header title
$sigheader = "Il Significatore "; //card 1 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$sigtext = "Questa carta rappresenta il tuo stato attuale, come sei in questo momento.";
$crossheader = "La Carta Incrociata "; //card 2 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$crosstext = "La Carta determina quali sono i fattori che stanno avendo influenza sulla tua vita e in quale modo.";
$foundationheader = "La Carta della Fondazione "; //card 3 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$foundationtext = "Questa carta indica quali sono le radici, il punto di partenza iniziale della situazione.";
$recentheader ="Il Passato Recente "; //card 4 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$recenttext ="La Carta indica come gli eventi pi� recenti stanno agendo su di te in relazione alla tua domanda.";
$crownheader = "La Corona "; //card 5 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$crowntext = "Questa carta predice eventi futuri che si potrebbero o meno verificare a seconda delle scelte che prenderai in nel momento presente.";
$futureheader = "Il Futuro ";  //card 6 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$futuretext = "E' la carta degli avvenimenti futuri, che avverrano a prescindere dalle nostre azioni.";
$emotionsheader = "Emozioni "; //card 7 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$emotionstext = "Questa carta rappresenta il tuo attuale stato emotivo in riferimento alla domanda che hai posto.";
$externheader ="Influenze Esterne "; //card 8 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$externtext = "L'Arcano rappresenta le influenze da parte del mondo esterno e da parte delle persone che ti circondano.";
$hopesheader = "Desideri e Speranze "; //card 9  in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$hopestext = "La Carta rappresenta quello che ha influenza sulle tue aspirazioni e quali potrebbero essere le strategie per raggiungerle.";
$outcomeheader = "Il Risulatato ";  //card 10 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$outcometext = "In questa Carta, puoi trovare la sintesi, l'esito finale della domanda che hai posto. Questo Arcano non va visto come una carta definitiva, ma come il risultato di tutto il percorso fatto durante la lettura col metodo della Croce Celtica.";


//the variables below define the tetraktys spread's wording. use these to edit headers and header text
$tettitle = "Metodo del Triangolo: Lettura Tarocchi Gratis On Line - Responso"; // page title
$tetpagetitle = "Metodo del Triangolo: Lettura Tarocchi Gratis On Line - Responso"; // page header title
$fireheader = "La Carta dell'Elemento FUOCO "; //card 1 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$firetext = "rappresenta la forza creativa, la volont� e l'ambizione.";
$airheader = "La Carta dell'Elemento ARIA "; //card 2 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$airtext = "indica quali sono le strategie da adottare per raggiungere il tuo obbiettivo.";
$waterheader = "La Carta dell'Elemento ACQUA "; //card 3 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$watertext = "sono le tue emozioni profonde e il tuo stato emotivo.";
$earthheader ="La Carta dell'Elemento TERRA "; //card 4 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$earthtext ="riguarda le cose pratiche e concrete, la vita di tutti i giorni a livello materiale.";
$creatorheader = "La Carta del Creatore "; //card 5 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$creatortext = "rappresenta i fattori che ti spingono verso nuove direzioni.";
$sustainerheader = "La Carta del Sostenitore ";  //card 6 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$sustainertext = "indica ci� che vi aiuta a rimanere equilibrati e in salute";
$destroyerheader = "La Carta del Distruttore "; //card 7 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$destroyertext = "individua ci� che deve essere eliminato in modo da poter andare avanti";
$lightheader ="La carta della Luce "; //card 8 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$lighttext = "rappresenta la forza Cosmica che vi guida verso la realizzazione dei vostri obbiettivi.";
$darkheader = "La carta dell�Oscurit� "; //card 9  in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$darktext = "raffigura la reazione cosmica in base alle vostre azioni.";
$premiseheader = "La Premessa ";  //card 10 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$premisetext = "la sintesi della lettura e i fattori che stanno alla base della realizzzione finale.";


//the variables below define the daily influence spread's wording. use these to edit headers and header text
$dititle = "Le influenze odierne";
$dipagetitle = "Le tue influence odierne"; // page header title
$tarotheader = "Influenza dei tarocchi: ";
$astroheader = "Influenze Astrologiche";
$elementalheader = "Influenza degli elementi";

//the variables below define the astrological spread's wording. use these to edit headers and header text
$astrotitle = "Metodo Astrologico: Lettura Tarocchi Gratis On Line - Responso"; // page title
$astropagetitle = "Metodo Astrologico: Lettura Tarocchi Gratis On Line - Responso"; // header title
$selfheader = "La tua Situazione in Generale "; //card 1 in lower table
$currentheader = "Il tuo Attuale Stato d�Animo (La Carta dell'Ariete)  ";   //card 2 in lower table
$financeheader = "La tua sfera Economica e Finanziaria (La Carta del Toro) "; //card 3 in lower table
$travelheader = "I Viaggi e i Rapporti Interpersonali (La Carta dei Gemelli) ";//card 4 in lower table
$homeheader = "Le Questioni Legate alla Casa, Genitori e Figli (La Carta del Cancro) ";//card 5 in lower table
$pleasureheader = "La Sfera dei Piaceri e delle Passioni (La Carta del Leone) ";//card 6 in lower table
$healthheader = "Indica il tuo Stato Psicofisico (Carta della Vergine) "; //card 7 in lower table
$partnerheader = "Le Persone che stanno accanto a te e il Matrimonio (La Carta della Bilancia) "; //card 8 in lower table
$deathheader = "I Cambiamenti Importanti e le Eredit� (La Carta dello Scoprione) "; //card 9 in lower table
$spiritheader ="Le Questioni legate alla tua vita Spirituale, Intellettuale e ai tuoi Sogni  (La Carta del Sagittario)";//card 10 in lower table
$careerheader ="La Carriera e il Successo in ambito Professionale (La Carta del Capricorno) "; //card 11 in lower table
$friendheader = "I Rapporti con gli Amici e i Colleghi (La Carta dell'Acquario) "; //card 12 in lower table
$burdenheader = "Riguarda gli Ostacoli da Affrontare, le Sfide e le tue Paure (La Carta dei Pesci)"; //card 13 in lower table

//the variables below define the dream spread's wording. use these to edit headers and header text
$dreamtitle = "Metodo dell'Interpretazione dei Sogni: Lettura Tarocchi Gratis On Line - Responso"; // page title
$dreampagetitle = "Metodo dell'Interpretazione dei Sogni: Lettura Tarocchi Gratis On Line - Responso"; // header title
$dreamimportanceheader = "La Rilevanza che il Sogno Occupa nella tua Vita "; //card 1 in lower table
$dreamlessonheader = "La Lezione che il tuo Sogno sta cercando di trasmetterti "; //card 2 in lower table
$dreamuseheader = "Come applicare il Sogno nella vita di tutti i giorni "; //card 3 in lower table

//the variables below define the dream spread's wording. use these to edit headers and header text
$pastlifetitle = "Metodo della Vita Passata: Lettura Tarocchi Gratis On Line - Responso"; // page title
$pastlifepagetitle = "Metodo della Vita Passata: Lettura Tarocchi Gratis On Line - Responso"; // header title
$pastlifeemotionalheader = "Influenze Emotive della tua Vita Passata";
$pastlifementalheader = "Influenze Mentali della tua Vita Passata";
$pastlifespiritualheader = "Influenze Spirituali della tua Vita Passata";
$pastlifephysicalheader = "Influenze Fisiche della tua Vita Passata";
$pastlifekarmicdebtheader = "Il Debito Karmico da Estinguere";
$pastlifekarmiclessonheader = "La Lezione Karmica da Imparare";
$pastlifeimpactnowheader = "L'Impatto della tua Vita Passata sulla tua Vita Attuale";
$pastlifeimpactfutureheader = "L'Impatto della tua Vita Passata sul tuo Futuro in questa Vita";



//the variables below define the relationship spread's wording. use these to edit headers and header text
$rpagetitle = "Metodo delle Relazioni e dell'Amore: Lettura Tarocchi Gratis On Line - Responso"; // page title
$rtitle = "Metodo delle Relazioni e dell'Amore: Lettura Tarocchi Gratis On Line - Responso"; // header page title
$yourview = "Come vedi il tuo Partner";
$partnerview = "Come il tuo Partner vede te";
$yneeds = "I tuoi Bisogni e le tue Priorit�";
$pneeds = "I Bisogno e le Esigente del tuo Partner";
$current = "La situazione attuale della tua relazione";
$ypath = "La strada che tu vorresti che la tua relazione seguisse";
$ppath = "La strada che il tuo partner vorrebbe che la vostra relazione ";
$aspects = "Aspetti importanti della tua relazione da considerare";
$outcome = "Il risultato Finale - La sintesi della Lettura";

//the variables below define the planetar spread's wording. use these to edit headers and header text
$plpagetitle = "Metodo Planetario: Lettura Tarocchi Gratis On Line - Responso"; // page title
$pltitle = "Metodo Planetario: Lettura Tarocchi Gratis On Line - Responso"; // header title
$you = "Il Tuo Stato Attuale";
$moon = "Questioni che riguardano la tua Casa e la Famiglia (La Carta della Luna)";
$mercury = "Questioni che riguardano i Tuoi Affari, la Tua Abilit� e le Strategia da Adottare (La Carta Di Mercurio)";
$venus = "Questioni che riguardano l'Amore e la Tua Vita Affettiva (La Carta di Venere)";
$mars = "Questioni che riguardano i Tuoi Rivali e tutto quello che si Oppone a Te (La Carta di Marte)";
$jupitor = "Questioni che riguardano le Tue Finanze, le Amicizie e il Tuo Benessere Psicofisico (La Carta di Giove)";
$saturn = "Questioni che riguardano lo Studio e l'Intelletto (La Carta di Saturno)";
$ploutcome = "Il risultato Finale - La sintesi della Lettura";

//the variables below define the birthday spread's wording. use these to edit headers and header text
$bdpagetitle = "Metodo del Compleanno: Lettura Tarocchi Gratis On Line - Responso"; // page title
$bdtitle = "Metodo del Compleanno: Lettura Tarocchi Gratis On Line - Responso"; // header page title
$bdpresent = "La tua Posizione attuale nel Mondo";
$bdgoals = "I tuoi Obiettivi per il Prossimo Anno";
$bdpower = "Cosa ti Autorizza verso i tuoi Scopi";
$bddevelop = "Poteri necessari per sviluppare i tuoi Obbiettivi";
$bdmaterial = "Il tuo Attuale stato Materiale";
$bdemotion = "Il tuo Attuale stato Emotivo";
$bdspirit = "Il tuo Attuale stato Spirituale";
$bdoppose = "I Fattori che si Oppongono alla tua Meta";
$bddo = "Cosa necessiti per realizzare i tuoi obiettivi";

//the variables below define the mandal spread's wording. use these to edit headers and header text
$mpagetitle = "Metodo del Mandala: Lettura Tarocchi Gratis On Line - Responso"; // page title
$mtitle = "Metodo del Mandala: Lettura Tarocchi Gratis On Line - Responso"; // header title
$myou = "Il Tuo Stato Attuale";
$mambition = "Le tue Ambizioni, i tuoi Desideri e le Necessit� Primarie";
$mideals = "I tuoi Ideali, gli Obiettivi e i Percorsi di Realizzazione Spirituale";
$mreal = "Il Percorso Principale da Seguire per la tua Realizzazione";
$mdepend = "Le tue Dipendenze da Valori Errati e Inutili";
$mstrength = "I Tuoi Punti di Forza Relativi al tuo Carattere e alla tua Personalit�";
$mfaults = "I Tuoi Difetti e le tue Debolezze";
$mimage = "La Consapevolezza che hai di di te e della tua Immagine";
$mdesires = "I tuoi Desideri e i tuoi Obiettivi";

//the variables below define the star spread's wording. use these to edit headers and header text
$stpagetitle = "Metodo delle Stelle: Lettura Tarocchi Gratis On Line - Responso"; // page title
$sttitle = "Metodo delle Stelle: Lettura Tarocchi Gratis On Line - Responso"; // header title
$stpresent = "La tua Situazione Attuale";
$stcauses = "Le cause dei tuoi Conflitti e gli Ostacoli";
$stchanges = "I cambiamenti che vanno fatti per affrontare le tue Sfide";
$ststrengths = "I Tuoi Punti di Forza";
$stchallenges = "Altre Sfide da Affrontare";
$stoutcome = "Il risultato Finale - La sintesi della Lettura";

//the variables below define the tree of life spread's wording. use these to edit headers and header text
$tlpagetitle = "Metodo dell'Albero della Vita: Lettura Tarocchi Gratis On Line - Responso"; // page title
$tltitle = "Metodo dell'Albero della Vita: Lettura Tarocchi Gratis On Line - Responso"; // header title
$tlideals = "I tuoi Grandi Ideali";
$tlcreative = "Il tuo Potere Creativo";
$tlwisdom = "La tua Saggezza";
$tlvirtues = "Le tue Virt�";
$tlbeing = "La tua Forza d'Animo";
$tlhealth = "Il tuo Stato Psicofisico, la Bellezza e l'Altruismo";
$tllove = "I tuoi Amori, le tue Passioni, il tuo s� Artistico ed i tuoi Istinti ";
$tlprocreate = "Le tue Capacit� Realizzative nelle questioni Pratiche e la tua Inventiva";
$tlimagine ="La tua Immaginazione e i Poteri della tua Mente";
$tlphysical = "Il tuo Essere Fisico";

//the variables below define the cross and triangle spread's wording. use these to edit headers and header text
$ctpagetitle = "Metodo della Croce e Triangolo: Lettura Tarocchi Gratis On Line - Responso"; // page title
$cttitle = "Metodo della Croce e Triangolo: Lettura Tarocchi Gratis On Line - Responso"; // header title
$ctyou = "Il tuo Significatore e la tua Forza Vitale";
$ctthoughts = "Quello che Influenza i tuoi Pensieri";
$ctemotions = "Quello che Influenza le tue Emozioni";
$ctspirit = "Quello che Influenza il tuo Spirito";
$ctphysical = "Quello che ti Influenza Fisicamente";
$ctoppose = "Le Forze che si Oppongono a te";
$ctother = "Altri Ostacoli da Superare";
$ctenergies = "Energies You Need to bring to the Forefront";
$ctoutcome = "Il risultato Finale - La sintesi della Lettura";
