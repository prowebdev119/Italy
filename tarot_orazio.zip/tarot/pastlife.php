<?

include("config.php"); //db connection and directory variables
include("lang.php");


 $maxnumber = 8;
 $count= 0;
 $index = 0;
 $cardcount = 0;
 $cardindex = 0;
 $cards[0];
 $thecards[0][0];
 while($count <= $maxnumber)
{
     $number = rand(0,78);
     for($index; $index <= $maxnumber; $index++)
     {
        if($cards[$index] == $number)
        {
          $number = rand(0,78);
          $index = -1;
        }

     }
      $cards[$count] = $number;
      $randnum = rand(0,100);
      if($count != 0)
      {
        if(($randnum % 2) != 0)
        {
          $cards[$count] =  $cards[$count]."r";
        }
      }

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
       $sendprint = $printcards."&maxnumber=".$maxnumber;
?>


<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<TITLE>Metodo della Vita Passata - Lettura Tarocchi Gratis - Reponso.</TITLE>
<META NAME="Title" Content="Metodo della Vita Passata - Lettura Tarocchi Gratis - Reponso.">
<META NAME="Description" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Keywords" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Robots" Content="Index,Follow">
<META NAME="Language" Content="Italian it">
<META NAME="Autor" Content="Giaas">
<META NAME="Copyright" Content="� 2010 Giaas">
<link rel="stylesheet" type="text/css" href="tarot.css">
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106475490-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-106475490-1');
</script>
</head>

<body class="body" topmargin="0" marginheight="0">

<div align="center">
  <center>
<table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="genericstyle" align="center">
    <tr>
        <td  align="center">
            <p align="center"><SPAN class="header1"><?php include("alto.htm"); ?>
</span><SPAN class="header1"><br><? echo"$pastlifepagetitle";?></span><br>
</b></p>
        </td>
    </tr>
    <tr>
        <td  align="left">
            <p><br>
            <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x15, creato 24/02/10 */
google_ad_slot = "0763580921";
google_ad_width = 728;
google_ad_height = 15;
//-->

                        

                        
                    

                        

                        
                    
                    

                        

                        
                    

                        

                        
                    
                    
                    

                        

                        
                    

                        

                        
                    
                    

                        

                        
                    

                        

                        
                    
                    
                    
            </script>
            <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                                
                                                                    
                    
                                                                    
                                                                    
                    
                    
                                                                    
                                                                    
                    
                                                                    
                                                                    
                    
                    
                    
            </script>
<br><br><?echo"$titleblurb";?><br>
        &nbsp;</p>
        </td>
    </tr>
    <tr>
        <td colspan="4" valign="middle" align="center">
            <p><a href="index.htm"><font color="#990000"><b><?echo"$readlink";?></b></font></a><b><font color="#990000">
        &nbsp;&nbsp;&nbsp;</font><a href="disclaimer.htm" target="_blank"><font color="#990000"><?echo"$disclaimlink";?></font></a><font color="#990000"><!--&nbsp;&nbsp;&nbsp;<a href="interp.htm" target="_blank"><?echo"$interplink";?></a>-->&nbsp;&nbsp;&nbsp;</font></b><a href="pastlifeprint.php?pcards=<?echo $sendprint;?>" target="_blank"><font color="#990000"><b><?echo"$printlink";?></b></font></A><br><font color="#990000"><b>
            <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "8653742807";
google_ad_width = 728;
google_ad_height = 90;
//-->

            

            
                    

            

            
                    
            </script>
            <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                        
                                            
                    
            </script>
</b></font></p>
            <p>
&nbsp;</p>
        </td>
    </tr>
</table>

<div align="center">
	<table border="0" cellpadding="7" cellspacing="0" width="450" class="genericstyle">
		<tr>
			<td align="center">
			   <a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                           <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                       </td>
			<td align="center" colspan="2">
                           <a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                           <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                        </td>
			<td align="center" colspan="2">
			   <a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                           <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                        </td>
			<td align="center">
			    <a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                            <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                       </td>
		</tr>                                                                                                                                           
		<tr>
			<td align="center" colspan="2">
			  <a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                          <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                       </td>
			<td align="center" colspan="2">
			  <a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                         <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                       </td>
			<td align="center" colspan="2">
			  <a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                          <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                        </td>
		</tr>                                                                                                                                           
		<tr>
			<td align="center">
			&nbsp;</td>
			<td align="center" colspan="4">
			   <a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
                           <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
                        </td>
		</tr>                                                                                                                                           
		</table>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="80%" class="genericstyle">
            <tr>
                <td colspan="2" width="<?echo"$tablewidth";?>"> 
                    <p align="center"><br>
                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "5217054529";
google_ad_width = 728;
google_ad_height = 90;
//-->

                    

                    
                    

                    

                    
                    
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                        
                                                            
                    
                    </script>
<br>&nbsp;</p>
                </td>
            </tr>

    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="header1"><?echo"$pastlifeemotionalheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifeemotionalcard = $thecards[0][0]; echo"$pastlifeemotionalcard";?>
        
        <p><? $pastlifeemotionalmeaning = $thecards[0][1]; echo"$pastlifeemotionalmeaning";?></td>
    </tr>


    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$pastlifementalheader";?></span></td>
    </tr>
    <tr>
     <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifementalcard = $thecards[1][0]; echo"$pastlifementalcard";?>
        
        <p><? $pastlifementalmeaning = $thecards[1][1]; echo"$pastlifementalmeaning";?></td>
    </tr>

   <tr>
    <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$pastlifespiritualheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifespiritualcard = $thecards[2][0]; echo"$pastlifespiritualcard";?>
        
        <p><? $pastlifespiritualmeaning = $thecards[2][1]; echo"$pastlifespiritualmeaning";?></td>
    </tr>

<tr>
 <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$pastlifephysicalheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifephysicalcard = $thecards[3][0]; echo"$pastlifephysicalcard";?>
        
        <p><? $pastlifephysicalmeaning = $thecards[3][1]; echo"$pastlifephysicalmeaning";?></td>
    </tr>

<tr>
 <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$pastlifekarmicdebtheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifekarmicdebtcard = $thecards[4][0]; echo"$pastlifekarmicdebtcard";?>
        
        <p><? $pastlifekarmicdebtmeaning = $thecards[4][1]; echo"$pastlifekarmicdebtmeaning";?></td>
    </tr>

<tr>
<td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$pastlifekarmiclessonheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifekarmiclessoncard = $thecards[5][0]; echo"$pastlifekarmiclessoncard";?>
        
        <p><? $pastlifekarmiclessonmeaning = $thecards[5][1]; echo"$pastlifekarmiclessonmeaning";?></td>
    </tr>

<tr>
<td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$pastlifeimpactnowheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifeimpactnowcard = $thecards[6][0]; echo"$pastlifeimpactnowcard";?>
        
        <p><? $pastlifeimpactnowmeaning = $thecards[6][1]; echo"$pastlifeimpactnowmeaning";?></td>
    </tr>

<tr>
<td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$pastlifeimpactfutureheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pastlifeimpactfuturecard = $thecards[7][0]; echo"$pastlifeimpactfuturecard";?>
        
        <p><? $pastlifeimpactfuturemeaning = $thecards[7][1]; echo"$pastlifeimpactfuturemeaning";?></td>
    </tr>
 
            <tr>
                <td colspan="4" valign="middle" align="center">
                    <p>

                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "4490136035";
google_ad_width = 728;
google_ad_height = 90;
//-->

                        

                        
                        

                        

                        
                        
                    

                        

                        
                        

                        

                        
                        
                    
                    

                        

                        
                        

                        

                        
                        
                    

                        

                        
                        

                        

                        
                        
                    
                    
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                                
                                                                        
                        
                                                                    
                                                                        
                        
                    
                                                                    
                                                                        
                        
                                                                    
                                                                        
                        
                    
                    
                    </script>
</p>
                    <p><a href="index.htm"><font color="#990000"><b>Nuova Lettura</b></font></a><b><font color="#990000">&nbsp;&nbsp;&nbsp; </font><a href="disclaimer.htm" target="_blank"><font color="#990000">Disclaimer</font></a><font color="#990000">&nbsp;&nbsp;&nbsp;</font></b><a href="planetprint.php?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank"><font color="#990000"><b><?echo"$printlink";?></b></font></A></p>
                    <P><SPAN class="copyright"><?echo"$copyright";?></SPAN></P>
                </td>
            </tr>
  </table>        <p><?php include("basso.htm"); ?></p>
        <p>
<!-- Histats.com  START  -->
<a href="http://www.histats.com/it/" target="_blank" title="contatore accessi">
            <script  type="text/javascript" language="javascript">var s_sid = 1044503;var st_dominio = 4;
var cimg = 14;var cwi =200;var che =40;

            </script></a>
<script  type="text/javascript" language="javascript" src="http://s11.histats.com/js9.js">
</script>
        <noscript><a href="http://www.histats.com/it/" target="_blank">
<img  src="http://s103.histats.com/stats/0.gif?1044503&1" alt="contatore accessi" border="0"></a>
</noscript><!-- Histats.com  END  --></p>

  </center>
</div>

</body>

</html>