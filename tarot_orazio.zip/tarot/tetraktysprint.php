<?
include("config.php"); //db connection and directory variables

//customize individual pages by changing these values
$pagebackground = "#FFFFFF"; //page background color
$pagetext = "#000000";  //page text color
$imageborder = "0"; // card border width. this must be set to a number larger than 0 for the images to have a border
$imagebordercolor = "#00FF00"; //set specific border color. will not work in old browsers
$linkcolor = "#00FF00";//set link color
$vlinkcolor = "#0000FF"; //set visited link color
$headercolor = "#00FF00"; //use this to set the color of headers
$imageborder = "2"; // card border width. this must be set to a number larger than 0 for the images to have a border
//$imagebordercolor = "#FF0000"; //set specific border color. will not work in old browsers
$imagewidth = "73";
$imageheight = "120";
$linkcolor = "#000000";//set link color
$vlinkcolor = "#000000"; //set visited link color
$headercolor = "#FF0000"; //use this to set the color of headers
$font = "Verdana"; //use this to set the page's font
$fontsize = "2"; //use this to set the page's font size

//the variables below define the page's wording. use these to edit headers and header text
$tettitle = "Your Tetraktys Spread"; // page title
$tetpagetitle = "Your Tetraktys Spread"; // page header title
$readlink = "Get Another Reading";
$disclaimlink = "Disclaimer";
$interplink = "Interpretation Basics";
$printlink = "Version to Print";
$titleblurb = "Scroll down for your interpretation. Click on individual cards to see a larger representation."; //blurb under page header
$fireheader = "The Fire Card "; //card 1 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$firetext = "represents your creative force, will, and ambition.";
$airheader = "The Air Card "; //card 2 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$airtext = "Your current strategies and thoughts concerning your goals";
$waterheader = "The Water Card "; //card 3 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$watertext = "explores your emotional self.";
$earthheader ="The Earth Card "; //card 4 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$earthtext ="concerns how you dealing with everyday life.";
$creatorheader = "The Creator Card "; //card 5 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$creatortext = "explores that which drives you in new directions.";
$sustainerheader = "The Sustainer Card ";  //card 6 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$sustainertext = "depicts that which helping you remain balanced and healthy.";
$destroyerheader = "The Destroyer Card "; //card 7 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$destroyertext = "identifies that which must be jettisoned, so you can move forward.";
$lightheader ="The Light Card "; //card 8 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$lighttext = "represents the cosmic force which is guiding you towards fulfillment.";
$darkheader = "The Dark Card "; //card 9  in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$darktext = "represents the cosmic reaction to your being.";
$premiseheader = "The Premise ";  //card 10 in lower table ***NOTICE THE SPACE AT THE STRING'S END ***
$premisetext = "represents the factors that form the the foundation for the entire spread.";

$con= @mysql_connect("$host","$user","$pass");
if(!$con)
{
  $connect_error = "Failed at mysql_connect. ";
  echo"error at db connect";
  exit();
}
 $count=0;
 $index=0;
 //$maxnumber = 9;
 $pcards = $_GET['pcards'];
 $maxnumber = $_GET['maxnumber'];
 $cards = explode (":", $pcards);

 while($count <= $maxnumber)
{




       //echo"$cards[$count] <-----card<BR>"; //debug
      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>"; //debug
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;     //debug
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
?>


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">

<title><?echo"$tettitle";?></title>
</head>

<body topmargin="0" leftmargin="0"  bgcolor="<?echo"$pagebackground";?>" text="<?echo"$pagetext";?>" link="<?echo"$linkcolor";?>" vlink="<?echo"$vlinkcolor";?>">

<p>&nbsp;</p>

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="560">
    <tr>
      <td colspan="4" align="center"></td>
    </tr>
    <tr>
      <td colspan="4" align="center"><b><font color="<?echo"$headercolor";?>" face="<?echo"$font";?>" size="<?echo"$fontsize";?>">
        <? echo"$tetpagetitle";?></font><br>
        </b></td>
    </tr>
    <tr>
      <td colspan="4" align="left"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><?echo"$titleblurb";?><br>
        &nbsp;</font></td>
    </tr>
   <!-- <tr>
        <td colspan="4" valign="middle" align="center"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="index.htm"><?echo"$readlink";?></a>
        &nbsp;&nbsp;&nbsp;<a href="disclaimer.htm" target="_blank"><?echo"$disclaimlink";?></a><!--&nbsp;&nbsp;&nbsp;<a href="interp.htm" target="_blank"><?echo"$interplink";?></a>&nbsp;&nbsp;&nbsp;<a href="celticprint.php3?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank" ><?echo"$printlink";?></A><BR>&nbsp;</font></td>
    </tr> -->
    <tr><TD>
   <div align="center">
  <center>
  <table border="0" cellpadding="3" cellspacing="0" width="400">
    <tr>
      <td colspan="8" align="center"><a href="<?$thumb=$thecards[0][2]; $large=$thecards[0][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
    </tr>
    <tr>
      <td colspan="2" align="center">&nbsp;
        <p>&nbsp;</p>
        <p>&nbsp;</td>
      <td colspan="2" align="center"><a href="<?$thumb=$thecards[1][2]; $large=$thecards[1][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td colspan="2" align="center"><a href="<?$thumb=$thecards[2][2]; $large=$thecards[2][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td colspan="2" align="center"></td>
    </tr>
    <tr>
      <td colspan="3" align="right"><a href="<?$thumb=$thecards[3][2]; $large=$thecards[3][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td colspan="2" align="center"><a href="<?$thumb=$thecards[4][2]; $large=$thecards[4][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td colspan="3" align="left"><a href="<?$thumb=$thecards[5][2]; $large=$thecards[5][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
    </tr>
    <tr>
      <td align="right"><a href="<?$thumb=$thecards[6][2]; $large=$thecards[6][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td colspan="3" align="center"><a href="<?$thumb=$thecards[7][2]; $large=$thecards[7][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td colspan="3" align="center"><a href="<?$thumb=$thecards[8][2]; $large=$thecards[8][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td align="left"><a href="<?$thumb=$thecards[9][2]; $large=$thecards[9][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="3" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
    </tr>
    </table>
  </center>
</div>
</td></tr>
    <!-- end top here -->
    <tr>
      <td></td>
      <td></td>
      <td></td>
    </tr>
  </table>
  </center>
</div>
<div align="center">
  <center>
  <table border="0" cellpadding="5" cellspacing="0" width="590">
    <tr>
      <td width="588" colspan="2">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" width="588"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>" color="<?echo"$headercolor";?>"><b><?echo"$fireheader";?></b></font><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><?echo"$firetext";?></font></td>
    </tr>
    <tr>
      <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[9][2]; $large=$thecards[9][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $firecard = $thecards[9][0]; echo"$firecard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $firemeaning = $thecards[9][1]; echo"$firemeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="588" colspan="2"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><font color="<?echo"$headercolor";?>"><b><?echo"$airheader";?></b></font><?echo"$airtext";?></font></td>
    </tr>
    <tr>
       <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[8][2]; $large=$thecards[8][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $aircard = $thecards[8][0]; echo"$airard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $airmeaning = $thecards[8][1]; echo"$airmeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td colspan="2" width="588"><font color="<?echo"$headercolor";?>" face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><b><?echo"$waterheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$watertext";?></font></td>
    </tr>
    <tr>
       <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[7][2]; $large=$thecards[7][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $watercard = $thecards[7][0]; echo"$watercard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $watermeaning = $thecards[7][1]; echo"$watermeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="588" colspan="2"><font color="<?echo"$headercolor";?>" face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><b><?echo"$earthheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$earthtext";?></font></td>
    </tr>
    <tr>
       <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[6][2]; $large=$thecards[6][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $earthcard = $thecards[6][0]; echo"$earthcard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $earthmeaning = $thecards[6][1]; echo"$earthmeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="588" colspan="2"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><font color="<?echo"$headercolor";?>"><b><?echo"$creatorheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$creatortext";?></font></td>
    </tr>
    <tr>
       <td width="75" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[5][2]; $large=$thecards[5][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $creatorcard = $thecards[5][0]; echo"$creatorcard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $creatormeaning = $thecards[5][1]; echo"$creatormeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="586" colspan="2"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><font color="<?echo"$headercolor";?>"><b><?echo"$sustainerheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$sustainertext";?></font></td>
    </tr>
    <tr>
       <td width="75" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[4][2]; $large=$thecards[4][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $sustainercard = $thecards[4][0]; echo"$sustainercard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $sustainermeaning = $thecards[4][1]; echo"$sustainermeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="586" colspan="2"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><font color="<?echo"$headercolor";?>"><b><?echo"$destroyerheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$destroyertext";?></font>
      </td>
    </tr>
    <tr>
       <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[3][2]; $large=$thecards[3][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $destroyercard = $thecards[3][0]; echo"$destroyercard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $destroyermeaning = $thecards[3][1]; echo"$destroyermeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="586" colspan="2"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><font color="<?echo"$headercolor";?>"><b><?echo"$lightheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$lighttext";?></font></td>
    </tr>
    <tr>
       <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[2][2]; $large=$thecards[2][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $lightcard = $thecards[2][0]; echo"$lightcard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $lightmeaning = $thecards[2][1]; echo"$lightmeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="586" colspan="2"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><font color="<?echo"$headercolor";?>"><b><?echo"$darkheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$darktext";?></font>
      </td>
    </tr>
    <tr>
       <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[1][2]; $large=$thecards[1][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $darkcard = $thecards[1][0]; echo"$darkcard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $darkmeaning = $thecards[1][1]; echo"$darkmeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
    </tr>
    <tr>
      <td width="586" colspan="2"><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><font color="<?echo"$headercolor";?>"><b><?echo"$premiseheader";?></b></font><font size="<?echo"$fontsize";?>" face="<?echo"$font";?>"><?echo"$premisetext";?></font></td>
    </tr>
    <tr>
       <td width="75"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="<?$thumb=$thecards[0][2]; $large=$thecards[0][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo $imagedirectory."/".$thumb;?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></A><br>
        &nbsp;</font></td>
      <td width="511" valign="top"><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $premisecard = $thecards[0][0]; echo"$premisecard";?>
        </font>
        <p><font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><? $premisemeaning = $thecards[0][1]; echo"$premisemeaning";?></font></p>
        &nbsp;
        <p>&nbsp;
      </td>
        <br>
      </td>
    </tr>
    <tr>
        <td colspan="4" valign="middle" align="center"><!--<font face="<?echo"$font";?>" size="<?echo"$fontsize";?>"><a href="index.htm">Get
        Another Reading</a>&nbsp;&nbsp;&nbsp; <a href="disclaimer.htm" target="_blank">Disclaimer</a>&nbsp;&nbsp;&nbsp;<a href="celticprint.php3?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank" ><?echo"$printlink";?></A><BR>&nbsp;
        -->
        <P></font><font face="<?echo"$font";?>" size="<?echo"$copyfontsize";?>"><?echo"$copyright";?></P></font></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>