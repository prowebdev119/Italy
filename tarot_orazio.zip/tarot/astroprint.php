<?

include("config.php"); //db connection and directory variables
include("lang.php");

$pcards = $_GET['pcards'];
$maxnumber = $_GET['maxnumber'];
 
 $count= 0;
 $index = 0;
 $cards = explode (":", $pcards);
 while($count <= $maxnumber)
{
    
      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
       $sendprint = $printcards."&maxnumber=".$maxnumber;
?>


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" type="text/css" href="tarot.css">
<title><?echo"$astrotitle";?></title>
</head>

<body class="printbody">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="4" align="center"><SPAN class="printheader">
        <? echo"$astropagetitle";?></span><br>
        </b></td>
   </tr>
    
    
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[11][2]; $large=$thecards[11][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[12][2]; $large=$thecards[12][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"vspace="2" ></a></td>
      <td align="center"><a href="<? $thumb=$thecards[10][2]; $large=$thecards[10][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a></td>
      <td align="center"><a href="<? $thumb=$thecards[9][2]; $large=$thecards[9][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a><br>
        
        <a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a></td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"> &nbsp; </td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$selfheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $selfcard = $thecards[0][0]; echo"$selfcard";?>
        
        <p><? $selfmeaning = $thecards[0][1]; echo"$selfmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$currentheader";?></span></td>
    </tr>
    <tr>
     <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $moodcard = $thecards[1][0]; echo"$moodcard";?>
        
        <p><? $moodmeaning = $thecards[1][1]; echo"$moodmeaning";?></td>
    </tr>
    <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$financeheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $financecard = $thecards[2][0]; echo"$financecard";?>
        
        <p><? $financemeaning = $thecards[2][1]; echo"$financemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$travelheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $financecard = $thecards[3][0]; echo"$financecard";?>
        
        <p><? $financemeaning = $thecards[3][1]; echo"$financemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$homeheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $homecard = $thecards[4][0]; echo"$homecard";?>
        
        <p><? $homemeaning = $thecards[4][1]; echo"$homemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="83%" valign="top"><SPAN class="printheader"><?echo"$pleasureheader";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $pleasurecard = $thecards[5][0]; echo"$pleasurecard";?>
        
        <p><? $pleasuremeaning = $thecards[5][1]; echo"$pleasuremeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="83%" valign="top"><SPAN class="printheader"><?echo"$healthheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $healthcard = $thecards[6][0]; echo"$healthcard";?>
        
        <p><? $healthmeaning = $thecards[6][1]; echo"$healthmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$partnerheader";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $libracard = $thecards[7][0]; echo"$libracard";?>
        
        <p><? $librameaning = $thecards[7][1]; echo"$librameaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$deathheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $deathcard = $thecards[8][0]; echo"$deathcard";?>
        
        <p><? $deathmeaning = $thecards[8][1]; echo"$deathmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$spiritheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[9][2]; $large=$thecards[9][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $spiritcard = $thecards[9][0]; echo"$spiritcard";?>
        
        <p><? $spiritmeaning = $thecards[9][1]; echo"$spiritmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$careerheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[10][2]; $large=$thecards[10][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $jobcard = $thecards[10][0]; echo"$jobcard";?>
        
        <p><? $jobmeaning = $thecards[10][1]; echo"$jobmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$friendheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[11][2]; $large=$thecards[11][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $friendcard = $thecards[11][0]; echo"$friendcard";?>
        
        <p><? $friendmeaning = $thecards[11][1]; echo"$friendmeaning";?></td>
    </tr>
    <tr>
      <td width="83%" colspan="2"><SPAN class="printheader"><?echo"$burdenheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[12][2]; $large=$thecards[12][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $fearcard = $thecards[12][0]; echo"$fearcard";?>
        
        <p><? $fearmeaning = $thecards[12][1]; echo"$fearmeaning";?></td>
    </tr>
    <tr>
        <td colspan="4" valign="middle" align="center"><SPAN class="printcopyright"><?echo"$copyright";?></SPAN></P></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>