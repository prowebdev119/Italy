<?

include("config.php"); //db connection and directory variables
include("lang.php");
$pcards = $_GET['pcards'];
$maxnumber = $_GET['maxnumber'];

 $count= 0;
 $index = 0;
 
 while($count <= $maxnumber)
{
      $cards = explode (":", $pcards);

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       
?>

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><?echo"$pltitle";?></title>
<link rel="stylesheet" type="text/css" href="tarot.css">
</head>

 <body class="printbody">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="4" align="center">
        <SPAN class="printheader"><? echo"$plpagetitle";?>
        <br>&nbsp;
        </span></td>
    </tr>
   <tr>
      <td align="center"></td>
      <td colspan="2" align="center"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
        &nbsp;</td>
      <td align="center"></td>
    </tr>    
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
      <td align="center"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
        <br>
        <a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
      <td align="center"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
        <br>
        <a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
      <td align="center"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
    </tr>
    <tr>
      <td align="center"></td>
      <td colspan="2" align="center"><br>
        <a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>
      <td align="center"></td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"> &nbsp; </td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$you";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $selfcard = $thecards[0][0]; echo"$selfcard";?>
        
        <p><? $selfmeaning = $thecards[0][1]; echo"$selfmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$moon";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $homecard = $thecards[1][0]; echo"$homecard";?>
        
        <p><? $homemeaning = $thecards[1][1]; echo"$homemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$mercury";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $bizcard = $thecards[2][0]; echo"$bizcard";?>
        
        <p><? $bizmeaning = $thecards[2][1]; echo"$bizmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$venus";?></span></td>
    </tr>
    <tr>
     <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $lovecard = $thecards[3][0]; echo"$lovecard";?>
        
        <p><? $lovemeaning = $thecards[3][1]; echo"$lovemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$mars";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $oppcard = $thecards[4][0]; echo"$oppcard";?>
        
        <p><? $oppmeaning = $thecards[4][1]; echo"$oppmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$jupitor";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $financecard = $thecards[5][0]; echo"$financecard";?>
        
        <p><? $financemeaning = $thecards[5][1]; echo"$financemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$saturn";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $intellcard = $thecards[6][0]; echo"$intellcard";?>
        
        <p><? $intellmeaning = $thecards[6][1]; echo"$intellmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$outcome";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $outcard = $thecards[7][0]; echo"$outcard";?>
        
        <p><? $outmeaning = $thecards[7][1]; echo"$outmeaning";?></td>
    </tr>
    <tr>
        <td colspan="4" valign="middle" align="center"><P><SPAN class="printcopyright"><?echo"$copyright";?></span></P></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>