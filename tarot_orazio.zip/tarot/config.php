<?

//Script Copyright. Please do not remove this
echo"<!-- copyright 2001 The Scripts Joint -- Julian Laster All Rights Reserved -->";

$db = "Sql725610_1"; //set this to the name of your database
$host = "62.149.150.206"; //set this to the name of your host
$user = "Sql725610"; //set this to your db user name
$pass = "8su0ezbufl"; //set this to your db password
$table = "tcards"; //set this to the name of the table that holds the card info.

$imagedirectory = "images/"; //main image directory
$largeimage = ""; // large image directory. leave blank unless you want to move the larger cards.
$imageborder = "0"; // card border width. this must be set to a number larger than 0 for the images to have a border
$imagewidth = "110"; //width of card thumbnails that appear on pages
$imageheight = "160"; // height of card thumbnails that appear on pages

$tablewidth = "100%";//set the main table width on the spread pages with this.

$con= @mysql_connect("$host","$user","$pass");
if(!$con)
{
  $connect_error = "Failed at mysql_connect. ";
  echo"error at db connect";
  exit();
}

 srand((double)microtime()*1000000);

?>