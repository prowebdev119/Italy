<?

include("config.php"); //db connection and directory variables
include("lang.php");


$pcards = $_GET['pcards'];
$maxnumber = $_GET['maxnumber'];
 
 $count= 0;
 $index = 0;
 $cards = explode (":", $pcards);
 while($count <= $maxnumber)
{
      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
?>


<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<link rel="stylesheet" type="text/css" href="tarot.css">
<title><?echo"$dreamtitle";?></title>
</head>

<body class="printbody" >

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="4" align="center"><SPAN class="printheader">
        <? echo"$dreampagetitle";?></span><br>
        </b></td>
    </tr>
    <tr>
      <td colspan="4" align="left"><?echo"$titleblurb";?><br>
        &nbsp;</td>
    </tr>
     <tr>
      <td align="center">
        <a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
        
        <a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
        
        <a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" vspace="2"></a>
        </td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"> &nbsp; </td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$dreamimportanceheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $$dreamimportancecard = $thecards[0][0]; echo"$dreamimportancecard";?>
        
        <p><? $dreamimportancemeaning = $thecards[0][1]; echo"$dreamimportancemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$dreamlessonheader";?></span></td>
    </tr>
    <tr>
     <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $dreamlessoncard = $thecards[1][0]; echo"$dreamlessoncard";?>
        
        <p><? $dreamlessonmeaning = $thecards[1][1]; echo"$dreamlessonmeaning";?></td>
    </tr>
    <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="printheader"><?echo"$dreamuseheader";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $dreamusecard = $thecards[2][0]; echo"$dreamusecard";?>
        
        <p><? $dreamusemeaning = $thecards[2][1]; echo"$dreamusemeaning";?></td>
    </tr>
    
  </table>
  </center>
</div>

</body>

</html>