<?

include("config.php"); //db connection and directory variables
include("lang.php");

 $maxnumber = 7;
 $count= 0;
 $index = 0;
 $cardcount = 0;
 $cardindex = 0;
 $cards[0];
 $thecards[0][0];
 while($count <= $maxnumber)
{
     $number = rand(0,78);
     for($index; $index <= $maxnumber; $index++)
     {
        if($cards[$index] == $number)
        {
          $number = rand(0,78);
          $index = -1;
        }

     }
      $cards[$count] = $number;
      $randnum = rand(0,100);
      if($count != 0)
      {
        if(($randnum % 2) != 0)
        {
          $cards[$count] =  $cards[$count]."r";
        }
      }

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<TITLE>Metodo Planetario - Lettura Tarocchi Gratis - Reponso.</TITLE>
<META NAME="Title" Content="Metodo Planetario - Lettura Tarocchi Gratis - Reponso.">
<META NAME="Description" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Keywords" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Robots" Content="Index,Follow">
<META NAME="Language" Content="Italian it">
<META NAME="Autor" Content="Giaas">
<META NAME="Copyright" Content="� 2010 Giaas">
<link rel="stylesheet" type="text/css" href="tarot.css">
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106475490-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-106475490-1');
</script>
</head>

 <body class="body" topmargin="0" marginheight="0">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="genericstyle">
            <tr>
                <td colspan="4" align="center">

                    <p><SPAN class="header1"><?php include("alto.htm"); ?>
</span><SPAN class="header1"><br><? echo"$plpagetitle";?>
        <br>
        </span></p>
                </td>
            </tr>
            <tr>
                <td colspan="4" align="left">
                    <p><br>
                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x15, creato 24/02/10 */
google_ad_slot = "0763580921";
google_ad_width = 728;
google_ad_height = 15;
//-->

                        

                        
                    

                        

                        
                    
                    

                        

                        
                    

                        

                        
                    
                    
                    

                        

                        
                    

                        

                        
                    
                    

                        

                        
                    

                        

                        
                    
                    
                    
            

                        

                        
                    

                        

                        
                    
                    

                        

                        
                    

                        

                        
                    
                    
                    

                        

                        
                    

                        

                        
                    
                    

                        

                        
                    

                        

                        
                    
                    
                    
            
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                                
                                                                    
                    
                                                                    
                                                                    
                    
                    
                                                                    
                                                                    
                    
                                                                    
                                                                    
                    
                    
                    
                                                            
                                                                    
                    
                                                                    
                                                                    
                    
                    
                                                                    
                                                                    
                    
                                                                    
                                                                    
                    
                    
                    
            
                    </script>
<br><br><?echo"$titleblurb";?><br>
        &nbsp;</p>
                </td>
            </tr>
    <tr>
                <td colspan="4" valign="middle" align="center">
                    <p><a href="index.htm"><font color="#990000"><b><?echo"$readlink";?></b></font></a><b><font color="#990000">
        &nbsp;&nbsp;&nbsp;</font><a href="disclaimer.htm" target="_blank"><font color="#990000"><?echo"$disclaimlink";?></font></a><font color="#990000"><!--&nbsp;&nbsp;&nbsp;<a href="interp.htm" target="_blank"><?echo"$interplink";?></a>-->&nbsp;&nbsp;&nbsp;</font></b><a href="planetprint.php?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank"><font color="#990000"><b><?echo"$printlink";?></b></font></A><br><font color="#990000"><b>
                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "8653742807";
google_ad_width = 728;
google_ad_height = 90;
//-->

            

            
                    

            

            
                    
            

            

            
                    

            

            
                    
            
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                        
                                            
                    
                                    
                                            
                    
            
                    </script>
</b></font></p>
                    <p>&nbsp;</p>
                </td>
    </tr>
    <tr>
    <tr>
      <td align="center"></td>
      <td colspan="2" align="center"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        &nbsp;</td>
      <td align="center"></td>
    </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td align="center"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        <br>
        <a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td align="center"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><br>
        <br>
        <a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td align="center"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
    </tr>
    <tr>
      <td align="center"></td>
      <td colspan="2" align="center"><br>
        <a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
      <td align="center"></td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="80%" class="genericstyle">
            <tr>
                <td colspan="2" width="<?echo"$tablewidth";?>"> 
                    <p align="center">&nbsp; <br>
                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "5217054529";
google_ad_width = 728;
google_ad_height = 90;
//-->

                    

                    
                    

                    

                    
                    
                    

                    

                    
                    

                    

                    
                    
                    
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                        
                                                            
                    
                                                            
                                                            
                    
                    
                    </script>
<br>&nbsp;</p>
                </td>
            </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="header1"><?echo"$you";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $selfcard = $thecards[0][0]; echo"$selfcard";?>
        
        <p><? $selfmeaning = $thecards[0][1]; echo"$selfmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$moon";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $homecard = $thecards[1][0]; echo"$homecard";?>
        
        <p><? $homemeaning = $thecards[1][1]; echo"$homemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$mercury";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $bizcard = $thecards[2][0]; echo"$bizcard";?>
        
        <p><? $bizmeaning = $thecards[2][1]; echo"$bizmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$venus";?></span></td>
    </tr>
    <tr>
     <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $lovecard = $thecards[3][0]; echo"$lovecard";?>
        
        <p><? $lovemeaning = $thecards[3][1]; echo"$lovemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$mars";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $oppcard = $thecards[4][0]; echo"$oppcard";?>
        
        <p><? $oppmeaning = $thecards[4][1]; echo"$oppmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$jupitor";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $financecard = $thecards[5][0]; echo"$financecard";?>
        
        <p><? $financemeaning = $thecards[5][1]; echo"$financemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$saturn";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $intellcard = $thecards[6][0]; echo"$intellcard";?>
        
        <p><? $intellmeaning = $thecards[6][1]; echo"$intellmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>" valign="top"><SPAN class="header1"><?echo"$outcome";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $outcard = $thecards[7][0]; echo"$outcard";?>
        
        <p><? $outmeaning = $thecards[7][1]; echo"$outmeaning";?></td>
    </tr>
            <tr>
                <td colspan="4" valign="middle" align="center">
                    <p>

                    <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "4490136035";
google_ad_width = 728;
google_ad_height = 90;
//-->

                        

                        
                        

                        

                        
                        
                    

                        

                        
                        

                        

                        
                        
                    
                    

                        

                        
                        

                        

                        
                        
                    

                        

                        
                        

                        

                        
                        
                    
                    
                    

                        

                        
                        

                        

                        
                        
                    

                        

                        
                        

                        

                        
                        
                    
                    

                        

                        
                        

                        

                        
                        
                    

                        

                        
                        

                        

                        
                        
                    
                    
                    
                    </script>
                    <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                                
                                                                        
                        
                                                                    
                                                                        
                        
                    
                                                                    
                                                                        
                        
                                                                    
                                                                        
                        
                    
                    
                                                                    
                                                                        
                        
                                                                    
                                                                        
                        
                    
                                                                    
                                                                        
                        
                                                                    
                                                                        
                        
                    
                    
                    
                    </script>
</p>
                    <p><a href="index.htm"><font color="#990000"><b>Nuova Lettura</b></font></a><b><font color="#990000">&nbsp;&nbsp;&nbsp; </font><a href="disclaimer.htm" target="_blank"><font color="#990000">Disclaimer</font></a><font color="#990000">&nbsp;&nbsp;&nbsp;</font></b><a href="planetprint.php?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank"><font color="#990000"><b><?echo"$printlink";?></b></font></A></p>
                    <P><SPAN class="copyright"><?echo"$copyright";?></SPAN></P>
                </td>
            </tr>
  </table>        <p><?php include("basso.htm"); ?></p>
        <p>
<!-- Histats.com  START  -->
<a href="http://www.histats.com/it/" target="_blank" title="contatore accessi">
            <script  type="text/javascript" language="javascript">var s_sid = 1044503;var st_dominio = 4;
var cimg = 14;var cwi =200;var che =40;

            </script></a>
<script  type="text/javascript" language="javascript" src="http://s11.histats.com/js9.js">
</script>
        <noscript><a href="http://www.histats.com/it/" target="_blank">
<img  src="http://s103.histats.com/stats/0.gif?1044503&1" alt="contatore accessi" border="0"></a>
</noscript><!-- Histats.com  END  --></p>

  </center>
</div>

</body>

</html>