<?

include("config.php"); //db connection and directory variables
include("lang.php");

 $pcards = $_GET['pcards'];
 $maxnumber = $_GET['maxnumber'];
 $count= 0;
 $index = 0;
 $cards = explode (":", $pcards);

 while($count <= $maxnumber)
{
      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       
?>


<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><?echo"$tltitle";?></title>
<link rel="stylesheet" type="text/css" href="tarot.css">
</head>

<body class="printbody">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="3" align="center">
        <SPAN class="printheader"><? echo"$tlpagetitle";?></span><br>&nbsp;
        </b></td>
    </tr>
     <tr>
      <td align="center"><br>

        <a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a></td>

      <td align="center" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
      </td>
      <td align="center"><br>
        <a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>&nbsp;
      </td>
    </tr>
    <tr>
      <td align="center" valign="top">&nbsp;<br>
        <a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
      </td>
      <td align="center"><br>
        <br>
        <a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?> target="_blank""><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
      </td>
      <td align="center" valign="top"><BR>&nbsp;<a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?> target="_blank""><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>&nbsp;
      </td>
    </tr>
    <tr>
      <td align="center" valign="top"><BR>&nbsp;<a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
      </td>
      <td align="center"><br><BR>&nbsp;
        <a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
      </td>
      <td align="center" valign="top"><BR>&nbsp;<a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
      </td>
    </tr>
    <tr>
      <td align="center" colspan="3"><BR>&nbsp;<a href="<? $thumb=$thecards[9][2]; $large=$thecards[9][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>
      </td>
    </tr>
  </table>
  </center>
</div>

<p>&nbsp;</p>
<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$tlideals";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top" align="left"><? $idealcard = $thecards[0][0]; echo"$idealcard";?>
        
        <p><? $idealmeaning = $thecards[0][1]; echo"$idealmeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$tlcreative";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $forcecard = $thecards[1][0]; echo"$forcecard";?>
        
        <p><? $forcemeaning = $thecards[1][1]; echo"$forcemeaning";?></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$tlwisdom";?></font></td>
    </tr>
      <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $wisecard = $thecards[2][0]; echo"$wisecard";?>
        
        <p><? $wisemeaning = $thecards[2][1]; echo"$wisemeaning";?></td>
    </tr>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$tlvirtues";?></font></td>
    </tr>
    <tr>
      <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $virtuecard = $thecards[3][0]; echo"$virtuecard";?>
        
        <p><? $virtuemeaning = $thecards[3][1]; echo"$virtuemeaning";?></td>
    </tr>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$tlbeing";?></font></td>
    </tr>
    <tr>
      <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $forcecard = $thecards[4][0]; echo"$forcecard";?>
        
        <p><? $forcemeaning = $thecards[4][1]; echo"$forcemeaning";?></td>
    </tr>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$tlhealth";?></span></td>
    </tr>
    <tr>
      <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $beautycard = $thecards[5][0]; echo"$beautycard";?>
        
        <p><? $beautymeaning = $thecards[5][1]; echo"$beautymeaning";?></td>
    </tr>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$tllove";?></span></td>
    </tr>
    <tr>
      <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $idealcard = $thecards[6][0]; echo"$idealcard";?>
        
        <p><? $idealmeaning = $thecards[6][1]; echo"$idealmeaning";?></td>
    </tr>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$tlprocreate";?></font></td>
    </tr>
    <tr>
      <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $procard = $thecards[7][0]; echo"$procard";?>
        
        <p><? $promeaning = $thecards[7][1]; echo"$promeaning";?></td>
    </tr>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$tlimagine";?></span></td>
    </tr>
    <tr>
      <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $imaginecard = $thecards[8][0]; echo"$imaginecard";?>
        
        <p><? $imaginemeaning = $thecards[8][1]; echo"$imaginemeaning";?></td>
    </tr>
     <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$tlphysical";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[9][2]; $large=$thecards[9][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $physicalcard = $thecards[9][0]; echo"$physicalcard";?>
        
        <p><? $physicalmeaning = $thecards[9][1]; echo"$physicalmeaning";?></td>
    </tr>
     <tr>
        <td valign="middle" align="center" colspan="2"><P><SPAN class="printcopyright"><?echo"$copyright";?></span></P></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>