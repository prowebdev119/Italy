<?

include("config.php"); //db connection and directory variables
include("lang.php");
$pcards = $_GET['pcards'];
$maxnumber = $_GET['maxnumber'];
 
 $count= 0;
 $index = 0;
 $cards = explode (":", $pcards);
 while($count <= $maxnumber)
{
      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><?echo"$cttitle";?></title>
<link rel="stylesheet" type="text/css" href="tarot.css">
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106475490-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-106475490-1');
</script>
</head>

<body class="printbody">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" <?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td  align="center"><SPAN class="printheader">
        <? echo"$ctpagetitle";?></span><br>&nbsp;
        </td>
    </tr>
   
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        &nbsp;
      </td>
    </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
       <a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>&nbsp;
        <a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
      </td>
    </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
      </td>
    </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
      </td>
    </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
     &nbsp;<a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>&nbsp;
        <a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
    </tr>
    <tr>
      <td align="center"></td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="2" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$ctyou";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $selfcard = $thecards[0][0]; echo"$selfcard";?>
        
        <p><? $selfmeaning = $thecards[0][1]; echo"$selfmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$ctthoughts";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $thoughtcard = $thecards[1][0]; echo"$thoughtcard";?>
        
        <p><? $thoughtmeaning = $thecards[1][1]; echo"$thoughtmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$ctemotions";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $emotecard = $thecards[2][0]; echo"$emotecard";?>
        
        <p><? $emotemeaning = $thecards[2][1]; echo"$emotemeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$ctspirit";?></font></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $spiritcard = $thecards[3][0]; echo"$spiritcard";?>
        
        <p><? $spiritmeaning = $thecards[3][1]; echo"$spiritmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$ctphysical";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $physicalcard = $thecards[4][0]; echo"$physicalcard";?>
        
        <p><? $physicalmeaning = $thecards[4][1]; echo"$physicalmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$ctoppose";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $opposecard = $thecards[5][0]; echo"$opposecard";?>
        
        <p><? $opposemeaning = $thecards[5][1]; echo"$opposemeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$ctother";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $othercard = $thecards[6][0]; echo"$othercard";?>
        
        <p><? $othermeaning = $thecards[6][1]; echo"$othermeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$ctenergies";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $energycard = $thecards[7][0]; echo"$energycard";?>
        
        <p><? $energymeaning = $thecards[7][1]; echo"$energymeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$ctoutcome";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $outcomecard = $thecards[8][0]; echo"$outcomecard";?>
        
        <p><? $outcomemeaning = $thecards[8][1]; echo"$outcomemeaning";?></td>
    </tr>
    <tr>
        <td valign="middle" align="center" colspan="2"><P><SPAN class="printcopyright"><?echo"$copyright";?></span></P></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>