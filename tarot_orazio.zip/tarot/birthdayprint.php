<?

include("config.php"); //db connection and directory variables
include("lang.php");
 $pcards = $_GET['pcards'];
 $maxnumber = $_GET['maxnumber'];
 $cards = explode (":", $pcards);
 $count= 0;
 $index = 0;
 while($count <= $maxnumber)
{

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
?>

<html>

<head>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<title><?echo"$bdtitle";?></title>
<link rel="stylesheet" type="text/css" href="tarot.css">
</head>

<body class="printbody">

<div align="center">
  <center>
  <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="4" align="center"><SPAN class="printheader">
        <? echo"$bdpagetitle";?></span><br>
        </td>
    </tr>
       <tr>
      <td align="center"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank">
        <img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        &nbsp;</td>
    </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><br>&nbsp;
      </td>
    </tr>
    <tr>
      <td align="center"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" hspace ="4" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a><BR>&nbsp;</td>
    </tr>
  </table>
  </center>
</div>

<div align="center">
  <center>
  <table border="0" cellpadding="6" cellspacing="0" width="<?echo"$tablewidth";?>" class="printgenericstyle">
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"></td>
    </tr>
    <tr>
      <td colspan="2" width="<?echo"$tablewidth";?>"><SPAN class="printheader"><?echo"$bdpresent";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[0][2]; $large=$thecards[0][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $presentcard = $thecards[0][0]; echo"$presentcard";?>
        
        <p><? $presentmeaning = $thecards[0][1]; echo"$presentmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$bdgoals";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[1][2]; $large=$thecards[1][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $goalscard = $thecards[1][0]; echo"$goalscard";?>
        
        <p><? $goalsmeaning = $thecards[1][1]; echo"$goalsmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$bdpower";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[2][2]; $large=$thecards[2][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $powercard = $thecards[2][0]; echo"$powercard";?>
        
        <p><? $powermeaning = $thecards[2][1]; echo"$powermeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2" valign="top"><SPAN class="printheader"><?echo"$bddevelop";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[3][2]; $large=$thecards[3][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="<?echo"$tablewidth";?>" valign="top"><? $needcard = $thecards[3][0]; echo"$needcard";?>
        
        <p><? $needmeaning = $thecards[3][1]; echo"$needmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$bdmaterial";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[4][2]; $large=$thecards[4][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $materialcard = $thecards[4][0]; echo"$materialcard";?>
        
        <p><? $materialmeaning = $thecards[4][1]; echo"$materialmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$bdemotion";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[5][2]; $large=$thecards[5][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $emotecard = $thecards[5][0]; echo"$emotecard";?>
        
        <p><? $emotemeaning = $thecards[5][1]; echo"$emotemeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$bdspirit";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[6][2]; $large=$thecards[6][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $spiritcard = $thecards[6][0]; echo"$spiritcard";?>
        
        <p><? $spiritmeaning = $thecards[6][1]; echo"$spiritmeaning";?></td>
    </tr>
    <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$bdoppose";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[7][2]; $large=$thecards[7][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $opposecard = $thecards[7][0]; echo"$opposecard";?>
        
        <p><? $opposemeaning = $thecards[7][1]; echo"$opposemeaning";?></td>
    </tr>
     <tr>
      <td width="<?echo"$tablewidth";?>" colspan="2"><SPAN class="printheader"><?echo"$bddo";?></span></td>
    </tr>
    <tr>
      <td width="17%" valign="top"><a href="<? $thumb=$thecards[8][2]; $large=$thecards[8][3];echo"$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>" ></a>
        <br>
        </td>
      <td width="83%" valign="top"><? $needcard = $thecards[8][0]; echo"$needcard";?>
        
        <p><? $needmeaning = $thecards[8][1]; echo"$needmeaning";?></td>
    </tr>
    <tr>
        <td colspan="2" valign="middle" align="center"><SPAN class="printcopyright"><?echo"$copyright";?></P></span></td>
    </tr>
  </table>
  </center>
</div>

</body>

</html>