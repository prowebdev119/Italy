<?
include("config.php"); //db connection and directory variables
include("lang.php");


 $maxnumber = 9;
 $count= 0;
 $index = 0;
 $cardcount = 0;
 $cardindex = 0;
 $cards[0];
 $thecards[0][0];
 while($count <= $maxnumber)
{
     $number = rand(0,78);
     for($index; $index <= $maxnumber; $index++)
     {
        if($cards[$index] == $number)
        {
          $number = rand(0,78);
          $index = -1;
        }

     }
      //echo"$number <-- number<BR>";
      $cards[$count] = $number;
      $randnum = rand(0,100);
      if($count != 0 && $count != 1)
      {
        if(($randnum % 2) != 0)
        {
          $cards[$count] =  $cards[$count]."r";
        }
      }

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
?>


<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<TITLE>Metodo della Croce Celtica - Lettura Tarocchi Gratis - Reponso.</TITLE>
<META NAME="Title" Content="Metodo della Croce Celtica - Lettura Tarocchi Gratis - Reponso.">
<META NAME="Description" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Keywords" Content="Pensa alla tua Domanda e fai Click per il Respondo. Tarocchi Gratis, Cartomanzia Virtuale Gratuita, dell'Amore e Lavoro.">
<META NAME="Robots" Content="Index,Follow">
<META NAME="Language" Content="Italian it">
<META NAME="Autor" Content="Giaas">
<META NAME="Copyright" Content="� 2010 Giaas">
<link rel="stylesheet" type="text/css" href="tarot.css">
<!-- Global Site Tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-106475490-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments)};
  gtag('js', new Date());

  gtag('config', 'UA-106475490-1');
</script>
</head>

<body class="body" topmargin="0" marginheight="0">

<table border="0" cellspacing="0" cellpadding="0" width="100%">
    <tr>
        <td width="963">
            <table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="genericstyle" align="center">
                <tr>
                    <td colspan="4" align="center"></td>
                </tr>
                <tr>
                    <td colspan="4" align="center">

                        <p><SPAN class="header1">
						<?php include("alto.htm"); ?>
						<br><? echo"$ccpagetitle";?></span><br></p>
                        <p>
                        <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x15, creato 24/02/10 */
google_ad_slot = "0763580921";
google_ad_width = 728;
google_ad_height = 15;
//-->

                        </script>
                        <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                        </script>
<br><br></b></p>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" align="left"><?echo"$titleblurb";?><br>
        &nbsp;</font></td>
                </tr>
                <tr>
                    <td colspan="4" valign="middle" align="center">
                        <p><a href="index.htm"><b><font color="#990000"><?echo"$readlink";?></font></b></a><b><font color="#990000">
        &nbsp;&nbsp;&nbsp;</font><a href="disclaimer.htm" target="_blank"><font color="#990000"><?echo"$disclaimlink";?></font></a><font color="#990000"><!--&nbsp;&nbsp;&nbsp;<a href="interp.htm" target="_blank"><?echo"$interplink";?></a>-->&nbsp;&nbsp;&nbsp;</font><a href="celticprint.php?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank"><font color="#990000"><?echo"$printlink";?></font></A></b></p>
                        <p>&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="3" align="center"><a href="<?$thumb=$thecards[2][2]; $large=$thecards[2][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
                    <td rowspan="4">
                        <p><a href="<?$thumb=$thecards[9][2]; $large=$thecards[9][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <BR><a href="<?$thumb=$thecards[8][2]; $large=$thecards[8][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <BR><a href="<?$thumb=$thecards[7][2]; $large=$thecards[7][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <BR><a href="<?$thumb=$thecards[6][2]; $large=$thecards[6][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
</p>
                    </td>
                </tr>
                <tr>
                    <td align="right"><a href="<?$thumb=$thecards[3][2]; $large=$thecards[3][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
                    <td align="center"><a href="<?$thumb=$thecards[1][2]; $large=$thecards[1][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><BR>
      <a href="<?$thumb=$thecards[0][2]; $large=$thecards[0][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
                    <td align="center"><a href="<?$thumb=$thecards[5][2]; $large=$thecards[5][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
                </tr>
                <tr>
                    <td align="center"></td>
                    <td align="center"><a href="<?$thumb=$thecards[4][2]; $large=$thecards[4][3]; echo "$imagedirectory$largeimage$large"?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
                    <td align="center"></td>
                </tr>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="963">
            <table border="0" cellpadding="5" cellspacing="0" width="80%" class="genericstyle" align="center">
                <tr>
                    <td width="651" colspan="2">

                        <p align="center"><br>
                        <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "5217054529";
google_ad_width = 728;
google_ad_height = 90;
//-->

                        </script>
                        <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                        </script>
</p>
                        <p>&nbsp;</p>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" width="651"><SPAN class="header1"><?echo"$sigheader";?></SPAN><?echo"$sigtext";?></td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[0][2]; $large=$thecards[0][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</td>
                    <td width="83%" valign="top"><? $sigcard = $thecards[0][0]; echo"$sigcard";?>
        
        
                        <p><? $sigmeaning = $thecards[0][1]; echo"$sigmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$crossheader";?></SPAN><?echo"$crosstext";?></td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[1][2]; $large=$thecards[1][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="550" valign="top"><? $crosscard = $thecards[1][0]; echo"$crosscard";?>
</font>

                        <p><? $crossmeaning = $thecards[1][1]; echo"$crossmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td colspan="2" width="98%"><SPAN class="header1"><?echo"$foundationheader";?></span><?echo"$foundationtext";?></td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[4][2]; $large=$thecards[4][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="550" valign="top"><? $foundcard = $thecards[4][0]; echo"$foundcard";?>
</font>

                        <p><? $foundmeaning = $thecards[4][1]; echo"$foundmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$recentheader";?></span><?echo"$recenttext";?></font></td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[3][2]; $large=$thecards[3][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="550" valign="top"><? $pastcard = $thecards[3][0]; echo"$pastcard";?>
</font>

                        <p><? $pastmeaning = $thecards[3][1]; echo"$pastmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$crownheader";?></SPAN><?echo"$crowntext";?></td>
                </tr>
                <tr>
                    <td width="14%" valign="top"><a href="<?$thumb=$thecards[2][2]; $large=$thecards[2][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="550" valign="top"><? $crowncard = $thecards[2][0]; echo"$crowncard";?>
</font>

                        <p><? $crownmeaning = $thecards[2][1]; echo"$crownmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$futureheader";?></span><?echo"$futuretext";?></font></td>
                </tr>
                <tr>
                    <td width="14%" valign="top"><a href="<?$thumb=$thecards[5][2]; $large=$thecards[5][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="83%" valign="top"><? $futurecard = $thecards[5][0]; echo"$futurecard";?>
</font>

                        <p><? $futuremeaning = $thecards[5][1]; echo"$futuremeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$emotionsheader";?></SPAN><?echo"$emotionstext";?></font>
</td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[6][2]; $large=$thecards[6][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="83%" valign="top"><? $emotecard = $thecards[6][0]; echo"$emotecard";?>
</font>

                        <p><? $emotemeaning = $thecards[6][1]; echo"$emotemeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$externheader";?></SPAN><?echo"$externtext";?></font></td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[7][2]; $large=$thecards[7][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="83%" valign="top"><? $externcard = $thecards[7][0]; echo"$externcard";?>
</font>

                        <p><? $externmeaning = $thecards[7][1]; echo"$externmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$hopesheader";?></SPAN><?echo"$hopestext";?></font>
</td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[8][2]; $large=$thecards[8][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="83%" valign="top"><? $hopecard = $thecards[8][0]; echo"$hopecard";?>
</font>

                        <p><? $hopemeaning = $thecards[8][1]; echo"$hopemeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td width="98%" colspan="2"><SPAN class="header1"><?echo"$outcomeheader";?></SPAN><?echo"$outcometext";?></font></td>
                </tr>
                <tr>
                    <td width="14%"><a href="<?$thumb=$thecards[9][2]; $large=$thecards[9][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></A><br>
        &nbsp;</font></td>
                    <td width="83%" valign="top"><? $outcard = $thecards[9][0]; echo"$outcard";?>
</font>

                        <p><? $outmeaning = $thecards[9][1]; echo"$outmeaning";?></p>
        &nbsp;
        <p>&nbsp;
      
      </td>
                </tr>
                <tr>
                    <td colspan="4" valign="middle" align="center" width="653">

                        <p align="center">

                        <script type="text/javascript">
<!--
google_ad_client = "pub-9762063220248999";
/* 728x90, creato 24/02/10 */
google_ad_slot = "4490136035";
google_ad_width = 728;
google_ad_height = 90;
//-->

                        

                        
                        

                        

                        
                        
                        </script>
                        <script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
                                                
                                                                        
                        
                        </script>
</p>
                        <p align="center"><a href="index.htm"><font color="#990000"><b>Nuova Lettura</b></font></a><b><font color="#990000">&nbsp;&nbsp;&nbsp; </font><a href="disclaimer.htm" target="_blank"><font color="#990000">Disclaimer</font></a><font color="#990000">&nbsp;&nbsp;&nbsp;</font></b><a href="planetprint.php?pcards=<?echo $printcards."&maxnumber=".$maxnumber;?>" target="_blank"><font color="#990000"><b><?echo"$printlink";?></b></font></A></p>
                        <P align="center"><SPAN class="copyright"><?echo"$copyright";?></SPAN></P>




                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table><p align="center"><?php include("basso.htm"); ?></p>
<p align="center">
<!-- Histats.com  START  -->
<a href="http://www.histats.com/it/" target="_blank" title="contatore accessi">
            <script  type="text/javascript" language="javascript">var s_sid = 1044503;var st_dominio = 4;
var cimg = 14;var cwi =200;var che =40;

            </script></a>
<script  type="text/javascript" language="javascript" src="http://s11.histats.com/js9.js">
</script>
<noscript><a href="http://www.histats.com/it/" target="_blank">
<img  src="http://s103.histats.com/stats/0.gif?1044503&1" alt="contatore accessi" border="0"></a>
</noscript><!-- Histats.com  END  --></p>



</body>

</html>