<?
include("config.php"); //db connection and directory variables
include("lang.php");


 $maxnumber = 9;
 $count= 0;
 $index = 0;
 $cardcount = 0;
 $cardindex = 0;
 $cards[0];
 $thecards[0][0];
 while($count <= $maxnumber)
{
     $number = rand(0,78);
     for($index; $index <= $maxnumber; $index++)
     {
        if($cards[$index] == $number)
        {
          $number = rand(0,78);
          $index = -1;
        }

     }
      //echo"$number <-- number<BR>";
      $cards[$count] = $number;
      $randnum = rand(0,100);
      if($count != 0 && $count != 1)
      {
        if(($randnum % 2) != 0)
        {
          $cards[$count] =  $cards[$count]."r";
        }
      }

      $query = "SELECT * FROM $table WHERE (card = '$cards[$count]')";
      $result = @mysql_db_query($db, $query);
      $r = mysql_fetch_array($result);

      if(!$result)
      {
         $query_error = "Failed at the mysql_db_query.";
         echo"$query_error";
         exit();
      }
      else
      {
        $indice = 0;
        $thecards[$count][$indice] =  $r["title"];
        $test2 = $r["card"];
        //echo"$test2 <-------no array value test <--->cards count --> $cards[$count]<BR>";
        $test = $thecards[$count][$indice];
        //echo"$test <-------test <BR>";
        $indice++;
        $thecards[$count][$indice] =  $r["description"];
        $indice++;
        $thecards[$count][$indice] =  $r["thumb"];
        $indice++;
        $thecards[$count][$indice] =  $r["limage"];
      }

      // $cards[$count] = $number;
      // echo"$cards[$count]<---CARD  $count <---COUNT<br>";

       $count++;
       $index = 0;
}
       $count = 0;
       $index = 0;
       $printcards = implode (":", $cards);
?>
<!doctype html>
<html lang="en" class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="canonical" href="https://html5-templates.com/" />
    <title>Responsive HTML5 Page Layout Template</title>
    <meta name="description" content="Simple HTML5 Page layout template with header, footer, sidebar etc.">
    <link rel="stylesheet" href="style.css">
    <script src="script.js"></script>
	<link rel="stylesheet" type="text/css" href="tarot.css">
</head>

<body>
<h1 align="center"><header>		
		
		
		
    </header><section>		<strong>I Tarocchi Di Giaas<br>Consulto&nbsp;Gratis</strong><span style="font-family:arial; line-height:1;"><strong> </strong></span></section><section id="pageContent"><main role="main"><article></h1>
<p align="center">
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js">
</script>
<!-- 728x15, creato 24/02/10 -->
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:90px"
     data-ad-client="ca-pub-9762063220248999"
     data-ad-slot="0763580921"></ins>

<script>
     (adsbygoogle = window.adsbygoogle || []).push({});

</script>
</p>
<table border="0" cellpadding="0" cellspacing="0" width="<?echo"$tablewidth";?>" class="genericstyle" align="center">
    <tr>
        <td colspan="4" align="center"></td>
    </tr>
    <tr>
        <td colspan="4" align="center">
<p>
&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td colspan="4" align="left">        &nbsp;</td>
    </tr>
    <tr>
        <td colspan="4" valign="middle" align="center">

            <p><a href="index.htm"><b><font color="#990000"><?echo"$readlink";?></font></b></a><b><font color="#990000">
        &nbsp;&nbsp;&nbsp;</font></b></p>
            <p>&nbsp;</p>
        </td>
    </tr>
    <tr>
        <td colspan="3" align="center"><a href="<?$thumb=$thecards[2][2]; $large=$thecards[2][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
        <td rowspan="4">

            <p><a href="<?$thumb=$thecards[9][2]; $large=$thecards[9][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <BR><a href="<?$thumb=$thecards[8][2]; $large=$thecards[8][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <BR><a href="<?$thumb=$thecards[7][2]; $large=$thecards[7][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
        <BR><a href="<?$thumb=$thecards[6][2]; $large=$thecards[6][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a>
</p>
        </td>
    </tr>
    <tr>
        <td align="right"><a href="<?$thumb=$thecards[3][2]; $large=$thecards[3][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
        <td align="center"><a href="<?$thumb=$thecards[1][2]; $large=$thecards[1][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a><BR>
      <a href="<?$thumb=$thecards[0][2]; $large=$thecards[0][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo "$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
        <td align="center"><a href="<?$thumb=$thecards[5][2]; $large=$thecards[5][3]; echo "$imagedirectory$largeimage$large";?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
    </tr>
    <tr>
        <td align="center"></td>
        <td align="center"><a href="<?$thumb=$thecards[4][2]; $large=$thecards[4][3]; echo "$imagedirectory$largeimage$large"?>" target="_blank"><img border="<?echo"$imageborder";?>" src="<?echo"$imagedirectory$thumb";?>" vspace="1" width="<?echo"$imagewidth";?>" height="<?echo"$imageheight";?>"></a></td>
        <td align="center"></td>
    </tr>
    <tr>
        <td></td>
        <td></td>
        <td></td>
    </tr>
</table>
<p align="center">&nbsp;                        </p>
				<h2>Stet facilis ius te</h2>
				<p>Lorem ipsum dolor sit amet, nonumes voluptatum mel ea, cu case ceteros cum. Novum commodo malorum vix ut. Dolores consequuntur in ius, sale electram dissentiunt quo te. Cu duo omnes invidunt, eos eu mucius fabellas. Stet facilis ius te, quando voluptatibus eos in. Ad vix mundi alterum, integre urbanitas intellegam vix in.</p>
			</article>
			<article>
				<h2>Illud mollis moderatius</h2>
				<p>Eum facete intellegat ei, ut mazim melius usu. Has elit simul primis ne, regione minimum id cum. Sea deleniti dissentiet ea. Illud mollis moderatius ut per, at qui ubique populo. Eum ad cibo legimus, vim ei quidam fastidii.</p>
			</article>
			<article>
				<h2>Ex ignota epicurei quo</h2>
				<p>Quo debet vivendo ex. Qui ut admodum senserit partiendo. Id adipiscing disputando eam, sea id magna pertinax concludaturque. Ex ignota epicurei quo, his ex doctus delenit fabellas, erat timeam cotidieque sit in. Vel eu soleat voluptatibus, cum cu exerci mediocritatem. Malis legere at per, has brute putant animal et, in consul utamur usu.</p>
			</article>
			<article>
				<h2>His at autem inani volutpat</h2>
				<p>Te has amet modo perfecto, te eum mucius conclusionemque, mel te erat deterruisset. Duo ceteros phaedrum id, ornatus postulant in sea. His at autem inani volutpat. Tollit possit in pri, platonem persecuti ad vix, vel nisl albucius gloriatur no.</p>
			</article>
		</main>
		
	</section>
	<footer>
		<p>� You can copy, edit and publish this template but please leave a link to our website | <a href="https://html5-templates.com/" target="_blank" rel="nofollow">HTML5 Templates</a></p>
		<address>
			Contact: <a href="mailto:me@example.com">Mail me</a>
		</address>
	</footer>


</body>

</html>